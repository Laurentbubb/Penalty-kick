const MAX_SHOTS = 10;
const HISTORY_SIZE = 5;

const state = {
  shot: 1,
  score: 0,
  combo: 0,
  history: [],
  locked: false,
  bestScore: Number(localStorage.getItem("penaltyMindBest") || 0)
};

const keeper = document.getElementById("keeper");
const ball = document.getElementById("ball");
const message = document.getElementById("message");
const shotNumber = document.getElementById("shotNumber");
const scoreElement = document.getElementById("score");
const comboElement = document.getElementById("combo");
const controls = document.getElementById("controls");
const result = document.getElementById("result");
const finalScore = document.getElementById("finalScore");
const bestScore = document.getElementById("bestScore");
const resultTitle = document.getElementById("resultTitle");

const directionPositions = {
  left: "27%",
  center: "50%",
  right: "73%"
};

function randomDirection() {
  const directions = ["left", "center", "right"];
  return directions[Math.floor(Math.random() * directions.length)];
}

function goalkeeperChooseDirection() {
  if (state.history.length === 0) {
    return randomDirection();
  }

  const counts = {
    left: 0,
    center: 0,
    right: 0
  };

  state.history.forEach(direction => counts[direction]++);

  const maxCount = Math.max(
    counts.left,
    counts.center,
    counts.right
  );

  const candidates = Object.keys(counts).filter(
    direction => counts[direction] === maxCount
  );

  const mostUsed =
    candidates[Math.floor(Math.random() * candidates.length)];

  const learningStrength =
    Math.min(0.35 + state.shot * 0.055, 0.9);

  if (Math.random() < learningStrength) {
    return mostUsed;
  }

  return randomDirection();
}

function calculatePoints(direction) {
  let points = direction === "center" ? 80 : 120;
  points += state.combo * 25;
  return points;
}

function animateShot(direction, goalkeeperDirection, scored) {
  keeper.style.left = directionPositions[goalkeeperDirection];

  ball.style.left = directionPositions[direction];
  ball.style.bottom = "285px";
  ball.style.transform =
    "translateX(-50%) scale(.65) rotate(360deg)";

  setTimeout(() => {
    if (scored) {
      message.textContent =
        "⚽ BUT ! +" +
        calculatePoints(direction) +
        " points";
    } else {
      message.textContent =
        "🧤 ARRÊT ! Le gardien t'a lu";
    }
  }, 420);
}

function resetBall() {
  ball.style.left = "50%";
  ball.style.bottom = "65px";
  ball.style.transform =
    "translateX(-50%) scale(1) rotate(0deg)";
  keeper.style.left = "50%";
}

function updateUI() {
  shotNumber.textContent =
    Math.min(state.shot, MAX_SHOTS);

  scoreElement.textContent = state.score;
  comboElement.textContent = state.combo;
}

function registerHistory(direction) {
  state.history.push(direction);

  if (state.history.length > HISTORY_SIZE) {
    state.history.shift();
  }
}

function setButtonsDisabled(disabled) {
  document.querySelectorAll(".shot-btn").forEach(button => {
    button.disabled = disabled;
  });
}

function shoot(direction) {
  if (state.locked || state.shot > MAX_SHOTS) {
    return;
  }

  state.locked = true;
  setButtonsDisabled(true);

  const goalkeeperDirection =
    goalkeeperChooseDirection();

  const scored =
    direction !== goalkeeperDirection;

  if (scored) {
    state.score += calculatePoints(direction);
    state.combo++;
  } else {
    state.combo = 0;
  }

  registerHistory(direction);
  animateShot(
    direction,
    goalkeeperDirection,
    scored
  );

  updateUI();

  setTimeout(() => {
    if (state.shot >= MAX_SHOTS) {
      finishGame();
      return;
    }

    state.shot++;
    state.locked = false;
    setButtonsDisabled(false);
    resetBall();

    message.textContent =
      `Tir ${state.shot} : choisis ta direction`;

    updateUI();
  }, 1100);
}

function finishGame() {
  state.locked = true;

  if (state.score > state.bestScore) {
    state.bestScore = state.score;

    localStorage.setItem(
      "penaltyMindBest",
      state.bestScore
    );

    resultTitle.textContent =
      "🏆 Nouveau record !";
  } else {
    resultTitle.textContent =
      "Fin de partie";
  }

  finalScore.textContent = state.score;
  bestScore.textContent = state.bestScore;

  controls.classList.add("hidden");
  result.classList.remove("hidden");
  message.textContent = "Partie terminée";
}

function restart() {
  state.shot = 1;
  state.score = 0;
  state.combo = 0;
  state.history = [];
  state.locked = false;

  result.classList.add("hidden");
  controls.classList.remove("hidden");

  setButtonsDisabled(false);
  resetBall();

  message.textContent =
    "Choisis une direction";

  updateUI();
}

document.querySelectorAll(".shot-btn").forEach(button => {
  button.addEventListener("click", () => {
    shoot(button.dataset.direction);
  });
});

document
  .getElementById("restartBtn")
  .addEventListener("click", restart);

updateUI();
