# ⚽ PenaltyMind

Prototype de jeu de penalties où le gardien analyse les habitudes du joueur.

## 🌐 Version navigateur

Fichiers principaux :

- `index.html`
- `style.css`
- `game.js`

Ouvre `index.html` dans un navigateur pour jouer.

## 🎮 Règles

- 10 tirs par partie.
- 3 directions : gauche, centre, droite.
- Le gardien mémorise les 5 derniers tirs.
- Il devient progressivement plus susceptible d'anticiper la direction la plus utilisée.
- Un but rapporte des points.
- Les buts consécutifs augmentent le combo.
- Le meilleur score est sauvegardé localement dans le navigateur.

## 🎯 Version Unity

`GameManager.cs` contient la logique de base à reprendre dans Unity.

## 🚀 Prochaines étapes

1. Ajouter de vraies animations du gardien.
2. Ajouter puissance et précision du tir.
3. Ajouter plusieurs personnalités de gardiens.
4. Ajouter le mode 1v1.
5. Ajouter le matchmaking.
6. Ajouter le classement.
7. Ajouter les défis quotidiens.
8. Ajouter les publicités récompensées.
9. Ajouter des skins et autres éléments cosmétiques.

## 📁 Structure

```text
PenaltyMind/
├── index.html
├── style.css
├── game.js
├── GameManager.cs
└── README.md
```
